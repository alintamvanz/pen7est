<?php
/*
@ Author : shutdown57 [ https://facebook.com/alinko.jp ]
@ JavCode - Java Code Rulez

@ maskamal - milio48 - bL@cKID 
 Source : https://github.com/PHPMailer/PHPMailer ( License : LGPL-2.1 )
*/

require 'src/sender.class.php';

$s57 = new s57_Sender();
$s57->s57_cekconfig();
echo $s57->s57_banner();

echo "1). Setting Up . \n";
echo "2). Reset Configuration \n ";
echo "\n\n";
echo "JavCode::optionz >> "; $opt = trim(fgets(STDIN));
if($opt == "1"){
echo "\n\n / Setting SMTP Server / \n\n";
$s57->s57_ask("SMTPHost");
$host = $s57->read;
$s57->s57_ask("SMTPPort");
$port = $s57->read;
$s57->s57_ask("SMTPUser");
$user = $s57->read;
$s57->s57_ask("SMTPPass");
$pass = $s57->read;
echo "[?] is the information that you provide is correct? [Y/n] "; $yn = trim(fgets(STDIN));
if($yn == "n" || $yn == "N" ){
	echo "[!] Exiting .. \n";
	echo "[i] Back here, for re-setup dude ! \n";
	exit;
}
$cfg = $s57->s57_model('smtp',array($host,$port,$user,$pass));
$s57->s57_saveconfig($cfg,'smtp.shutdown57');
echo "[i] Cleaning ... \n";
sleep(1);
@system('clear');
echo $s57->s57_banner();
echo "\n\n / Setting Email , list dll. / \n\n";
echo "[i] Kosongkan jika menggunakan fitur random,\n[i] Kecuali EmailList jangan Kosongkan ya goblog. \n";
$s57->s57_ask("EmailList");
$mailist = $s57->read;
$s57->s57_ask("SenderName");
$sender =(empty($s57->read)) ? "random" : $s57->read;
$s57->s57_ask("SenderMail");
$smail = (empty($s57->read)) ? "random" : $s57->read;
$s57->s57_ask("Subject");
$subj = (empty($s57->read)) ? "random" : $s57->read;
$s57->s57_ask("Letter");
$letter = $s57->read;
echo "[?] is the information that you provide is correct? [Y/n] "; $yn = trim(fgets(STDIN));
if($yn == "n" || $yn == "N"){
	echo "[!] Exiting .. \n";
	echo "[i] Back here, for re-setup dude ! \n";
	exit;
}
$cgf = $s57->s57_model('email',array($mailist,$sender,$smail,$subj,$letter));
$s57->s57_saveconfig($cgf,'email.shutdown57');
echo "[i] Cleaning ... \n";
sleep(2);
echo "[i] Check all Configuration ... \n";
sleep(1);
$s57->s57_checkall();
echo "[+] DONE !! 'shutdown57 sender' has been configured ! \n";
sleep(1);
echo "[i] Installing script ... \n";
$s57->s57_init();
sleep(1);
echo "--------------------------------[ JavCode | shutdown57 ]---------------------- \n";
}elseif($opt == "2")
{
	echo "[i] Removing Configuration ... \n";
	$s = scandir('config');
	foreach($s as $rm){
		if($rm == '..'|| $rm =='.')continue;
		if(@unlink('config/'.$rm))
		{
			echo "[+] config/".$rm." -> removed ! \n";
			usleep(5000);
		}
	}
	echo "[i] Done ! , cleaning up ... \n";
	sleep(1);
}