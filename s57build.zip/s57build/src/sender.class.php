<?php
/*
@ Author : shutdown57 [ https://facebook.com/alinko.jp ]
@ JavCode - Java Code Rulez

@ maskamal - milio48 - bL@cKID 
 Source : https://github.com/PHPMailer/PHPMailer ( License : LGPL-2.1 )
*/
date_default_timezone_set('Asia/Tokyo');

header('Content-type: text/plain; charset=utf-8');


Class s57_Sender{
	public $read;
	public function s57_banner()
	{
		print "     _              ____          _      
    | | __ ___   __/ ___|___   __| | ___ 
 _  | |/ _` \ \ / / |   / _ \ / _` |/ _ \
| |_| | (_| |\ V /| |__| (_) | (_| |  __/
 \___/ \__,_| \_/  \____\___/ \__,_|\___|
                                         
";
echo "+-----------[ Mail Sender by : shutdown57 ]-----------+ \n";
	}
	public function s57_cekconfig(){
		echo "[!] Checking configuration ... \n";
		sleep(1);
		if(!file_exists('config/hellcome.shutdown57')){
			echo "[i] file 'config/hellcome.shutdown57' not exists ... \n";
			sleep(1);
			echo "[+] Creating ... \n";
			@mkdir('config',0777);
			@touch('config/hellcome.shutdown57');
			$content = "// hellcome, We Are JavCode . Don't Remove this file dude. ! \n"; 
			@file_put_contents('config/hellcome.shutdown57',$content);
			echo "[i] Checking again ... \n";
			sleep(1);
			$this->s57_cekconfig();
		}else{
			echo "[+] Config exists ... ! \n";
			sleep(1);
			system('clear');
		}
	}
	public function s57_checkall(){
		$re = "[!] Please , re-setup / re-run this script .. \n";
		if(file_exists('config/hellcome.shutdown57'))
		{
			echo "[+] config/hellcome.shutdown57 : Exists ! \n";
		}else{
			echo "[-] config/hellcome.shutdown57 : Not exist ! \n";
			echo $re; exit;
		}
		sleep(1);
		if(file_exists('config/smtp.shutdown57'))
		{
			echo "[+] config/smtp.shutdown57     : Exists ! \n";
		}else{
			echo "[-] config/smtp.shutdown57 : Not exist ! \n";
			echo $re; exit;
		}
		sleep(1);
		if(file_exists('config/email.shutdown57'))
		{
			echo "[+] config/email.shutdown57    : Exists ! \n";
		}else{
			echo "[-] config/email.shutdown57 : Not exist ! \n";
			echo $re; exit;
		}
		sleep(1);
	}
	public function s57_init()
	{
		if(file_exists('src/init.shutdown57'))
		{
			copy('src/init.shutdown57','./shutdown57.php');
			if(file_exists('shutdown57.php'))
			{
				echo "[+] Welcome ! shutdown57.php already come~~ \n";
				sleep(1);
				@unlink('src/init.shutdown57');
				echo "[+] Finished ! , now you can run 'php shutdown57.php' in your command line \n";
			}else{
				echo "[-] Failed ! \n";
				exit;
			}
		}
	}
	public function s57_ask($text)
	{
		echo "JavCode::".$text." >> "; $this->read = trim(fgets(STDIN));
	}
	public function s57_saveconfig($text,$filename)
	{
			$fp = fopen('config/'.$filename,'w');
			fwrite($fp,$text);
			fclose($fp);
			$c = fopen('config/hellcome.shutdown57','a');
			fwrite($c,"@eval(file_get_contents('config/".$filename."')); \n");
			fclose($c);
		if (file_exists('config/'.$filename)) {
			echo "[+] Creating configuration done ! \n";
		}else{
			echo "[-] Failed to create configuration :( \n";
		}
	}
	public function s57_model($model = 'smtp',$text = array())
	{
		if($model == 'smtp')
		{
			$isi = "\$smtphost = '".$text[0]."'; \n";
			$isi.= "\$smtpport = '".$text[1]."'; \n";
			$isi.= "\$smtpuser = '".$text[2]."'; \n";
			$isi.= "\$smtppass = '".$text[3]."'; \n";
		}elseif($model == 'email')
		{
			$isi = "\$maillist = '".$text[0]."'; \n";
			$isi.= "\$sendername = '".$text[1]."'; \n";
			$isi.= "\$sendermail = '".$text[2]."'; \n";
			$isi.= "\$subject = '".$text[3]."'; \n";
			$isi.= "\$letter = '".$text[4]."'; \n";
		}
		return $isi;
	}
	public function s57_random($jenis = 'str',$max)
	{
		if($jenis == 'str')
		{
			$char = "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM";
			for ($i=0; $i <= $max; $i++) { 
				$get = rand(0,strlen($char)-1);
				@$ret.=$char[$get];
			}
		}elseif($jenis == 'num')
		{
			$char = "1234567890";
			for ($i=0; $i <= $max ; $i++) { 
				$get = rand(0,strlen($char)-1);
				@$ret.=$char[$get];
			}
		}elseif($jenis == 'mix'){
			$char = "1234567890poiuytrewqazxsdcvfgbnhjmklQAZXSWEDCVFRTGBNHYUJMKIOLP";
			for ($i=0; $i <= $max; $i++) { 
				$get = rand(0,strlen($char)-1);
				@$ret.=$char[$get];
			}
		}

		return $ret;
	}
	public function s57_random_sendername($rand){
	switch($rand){
	case '1': $sn = 'Secure Apple';
	break;
	case '2': $sn = 'Secure@apple.com';
	break;
	case '3': $sn = 'Apple Support';
	break;
	case '4': $sn = 'AppleID';
	break;
	case '5': $sn = 'Apple Recovery';
	break;
	case '6': $sn = 'Apple Notice';
	break;
	case '7': $sn = 'iCloud';
	break;
	case '8': $sn = 'iMessage';
	break;
	case '9': $sn = 'Apple Apps';
	break;
	default: $sn = 'AppleID';
	break;
	}
	return $sn;
}
	public function s57_random_sendermail($rand){
		switch($rand){
case '1': $name = "noreply-".$this->s57_random('str',8)."@icloud.me"; 
break; 
case'2': $name = "noreply-".$this->s57_random('str',8)."@m.apple.me"; 
break; 
case'3': $name = "noreply-".$this->s57_random('str',8)."@services.apple.com"; 
break; 
case'4': $name = "noreply-".$this->s57_random('str',8)."@reminder.icloud.com"; 
break; 
case'5': $name = "noreply-".$this->s57_random('str',8)."@imessage.apple.com"; 
break; 
case'6': $name = "noreply-".$this->s57_random('str',8)."@imessage.icloud.com"; 
break; 
case'7': $name = "noreply-".$this->s57_random('str',8)."@notifications.apple.com"; 
break; 
case'8': $name = "noreply-".$this->s57_random('str',8)."@appleid.com";
break;
case'9': $name = "noreply-".$this->s57_random('str',8)."@apple.com";
break;
default: $name = "noreply-".$this->s57_random('str',8)."@notifications.icloud.com"; 
break; 
} return $name; 
}
public function s57_random_subject($rand){
$r = rand(1000,9999); 
switch ($rand) {
case '1': $name = "Reminder : Login Autorized Apple ID"; 
break; 
case'2': $name = "Apple ID Login Activation ".$this->s57_random('mix',8).""; 
break; 
case'3': $name = "Notice : Security Alert From Your Apple ID "; 
break; 
case'4': $name = "Reminder : Apple ID Token ".$this->s57_random('mix',8).""; 
break; 
case'5': $name = "Apple ID Notification #" .rand(1,100). "." .rand(1,100). "." .rand(1,100). "." .rand(1,100). ""; 
break; 
case'6': $name = "Apple ID Security Notice #" .rand(1,100). "." .rand(1,100). "." .rand(1,100). "." .rand(1,100). ""; 
break; 
case'7': $name = "Apple ID Locked #" .rand(1,100). "." .rand(1,100). "." .rand(1,100). "." .rand(1,100). ""; 
break; 
case'8': $name = "Your Apple ID Has Be Disabled Notice #" .rand(1,100). "." .rand(1,100). "." .rand(1,100). "." .rand(1,100). ""; 
break; 
case'9': $name = "Your Apple ID Recicpt Order #" .rand(1,100). "." .rand(1,100). "." .rand(1,100). "." .rand(1,100). " Please Check Your Order."; 
break; 
default: $name = "Apple ID Disable Temporary Account #".$this->s57_random('str',8).""; 
break; 
} return $name; 

}
}

